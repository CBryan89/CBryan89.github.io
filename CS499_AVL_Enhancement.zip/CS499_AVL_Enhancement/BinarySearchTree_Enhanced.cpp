//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : Christopher Bryan
// Original    : CS 300 Binary Search Tree Project
// Enhancement : CS 499 Algorithms and Data Structures
// Version     : 2.0
// Description : Enhanced the original binary search tree into a
//               self-balancing AVL tree. The enhancement adds node height
//               tracking, balance factor calculations, left and right
//               rotations, automatic rebalancing after insertion and
//               deletion, and AVL balance verification.
//============================================================================

#include <iostream>
#include <time.h>
#include <algorithm>
#include <cstdlib>
#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

// Internal structure for tree node
struct Node {
    Bid bid;
    Node *left;
    Node *right;
    int height; //tracks node height for AVL balancing

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
        height = 1; // new nodes begin as leaf nodes
    }

    // initialize with a bid
    Node(Bid aBid) :
            Node() {
        bid = aBid;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;

    int getHeight(Node* node);
    int getBalance(Node* node);
    bool isBalanced(Node* node);
    Node* rotateRight(Node* node);
    Node* rotateLeft(Node* node);

    Node* addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    void postOrder(Node* node);
    void preOrder(Node* node);
    void destroyTree(Node* node);
    Node* removeNode(Node* node, string bidId);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void PostOrder();
    void PreOrder();
    void Insert(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
    int GetTreeHeight();
    bool IsBalanced();
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    // Initialize housekeeping variables
    root = nullptr; //root is equal to nullptr
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    destroyTree(root);// recurse from root deleting every node
}

/**
 * Get the height of a node.
 *
 * @param node Node whose height will be returned
 * @return Height of the node, or 0 if the node is null
 */
int BinarySearchTree::getHeight(Node* node) {
    if (node == nullptr) {
        return 0;
    }

    return node->height;
}

/**
 * Calculate the balance factor of a node.
 *
 * Balance factor = height of left subtree - height of right subtree.
 * AVL nodes remain balanced when the result is -1, 0, or 1.
 *
 * @param node Node whose balance factor will be calculated
 * @return Balance factor of the node
 */
int BinarySearchTree::getBalance(Node* node) {
    if (node == nullptr) {
        return 0;
    }

    return getHeight(node->left) - getHeight(node->right);
}

/**
 * Check whether the tree satisfies AVL balance requirements.
 *
 * @param node Current node being checked
 * @return True if the subtree is balanced, otherwise false
 */
bool BinarySearchTree::isBalanced(Node* node) {
    if (node == nullptr) {
        return true;
    }

    int balance = getBalance(node);

    // Every AVL node must have a balance factor between -1 and 1
    if (balance < -1 || balance > 1) {
        return false;
    }

    // Recursively verify both subtrees
    return isBalanced(node->left) && isBalanced(node->right);
}

/**
 * Return the current height of the AVL tree.
 *
 * @return Height of the tree
 */
int BinarySearchTree::GetTreeHeight() {
    return getHeight(root);
}

/**
 * Verify that the entire AVL tree is balanced.
 *
 * @return True if the tree is balanced, otherwise false
 */
bool BinarySearchTree::IsBalanced() {
    return isBalanced(root);
}

/**
 * Perform a right rotation to rebalance a left-heavy subtree.
 *
 * @param node Root of the unbalanced subtree
 * @return New root of the balanced subtree
 */
Node* BinarySearchTree::rotateRight(Node* node) {
    Node* newRoot = node->left;
    Node* temp = newRoot->right;

    // Perform rotation
    newRoot->right = node;
    node->left = temp;

    // Update heights after rotation
    node->height = 1 + max(getHeight(node->left), getHeight(node->right));
    newRoot->height = 1 + max(getHeight(newRoot->left), getHeight(newRoot->right));

    return newRoot;
}

/**
 * Perform a left rotation to rebalance a right-heavy subtree.
 *
 * @param node Root of the unbalanced subtree
 * @return New root of the balanced subtree
 */
Node* BinarySearchTree::rotateLeft(Node* node) {
    Node* newRoot = node->right;
    Node* temp = newRoot->left;

    // Perform rotation
    newRoot->left = node;
    node->right = temp;

    // Update heights after rotation
    node->height = 1 + max(getHeight(node->left), getHeight(node->right));
    newRoot->height = 1 + max(getHeight(newRoot->left), getHeight(newRoot->right));

    return newRoot;
}

void BinarySearchTree::destroyTree(Node* node) {
    if (node != nullptr) {
        destroyTree(node->left);
        destroyTree(node->right);
        delete node;
    }
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
    // In order root
    this->inOrder(root);
	// call inOrder fuction and pass root
}

/**
 * Traverse the tree in post-order
 */
void BinarySearchTree::PostOrder() {
    // Post order root
    this->postOrder(root);
	// postOrder root
}

/**
 * Traverse the tree in pre-order
 */
void BinarySearchTree::PreOrder() {
    // Pre order root
    this->preOrder(root);// preOrder root
}

/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Bid bid) {
    // Insert the bid and update the root after AVL rebalancing
    root = addNode(root, bid);
}

/**
 * Remove a bid
 */
void BinarySearchTree::Remove(string bidId) {
    // Implement removing a bid from the tree
    root = this->removeNode(root, bidId);
	// remove node root bidID
}

/**
 * Search for a bid
 */
Bid BinarySearchTree::Search(string bidId) {
    // Implement searching the tree for a bid
    Node* current = root;// set current node equal to root

    while (current != nullptr) { // keep looping downwards until bottom reached or matching bidId found
    if (current->bid.bidId.compare(bidId) == 0) {
    		return current->bid; // if match found, return current bid
    		}
    if (bidId.compare(current->bid.bidId) < 0) {
    	current = current->left;  // if bid is smaller than current node then traverse left
    } else {
    	current = current->right;    // else larger so traverse right
    }
    	}
    Bid bid;
    return bid;
}

/**
 * Add a bid to the tree and rebalance using AVL rotations.
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 * @return Root of the balanced subtree
 */
Node* BinarySearchTree::addNode(Node* node, Bid bid) {

    // Perform normal binary search tree insertion
    if (node == nullptr) {
        return new Node(bid);
    }

    if (bid.bidId.compare(node->bid.bidId) < 0) {
        node->left = addNode(node->left, bid);
    }
    else if (bid.bidId.compare(node->bid.bidId) > 0) {
        node->right = addNode(node->right, bid);
    }
    else {
        // Bid IDs are unique, so do not insert duplicates
        return node;
    }

    // Update the height of the current node
    node->height = 1 + max(getHeight(node->left), getHeight(node->right));

    // Calculate the balance factor
    int balance = getBalance(node);

    // Left-Left case
    if (balance > 1 && bid.bidId.compare(node->left->bid.bidId) < 0) {
        return rotateRight(node);
    }

    // Right-Right case
    if (balance < -1 && bid.bidId.compare(node->right->bid.bidId) > 0) {
        return rotateLeft(node);
    }

    // Left-Right case
    if (balance > 1 && bid.bidId.compare(node->left->bid.bidId) > 0) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    // Right-Left case
    if (balance < -1 && bid.bidId.compare(node->right->bid.bidId) < 0) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    // Return the unchanged node if it is already balanced
    return node;
}

void BinarySearchTree::inOrder(Node* node) {
      // Pre order root
    if (node != nullptr) {  //if node is not equal to null ptr
    	inOrder(node->left); //InOrder not left

    	cout << node->bid.bidId << ": "
    		 << node->bid.title << " | "
		     << node->bid.amount << " | "
			 << node->bid.fund << endl;   //output bidID, title, amount, fund

    	inOrder(node->right); //InOder right
    }
}
void BinarySearchTree::postOrder(Node* node) {
      // Pre order root
      if (node != nullptr) {//if node is not equal to null ptr

    	  postOrder(node->left);  //postOrder left
    	  postOrder(node->right);  //postOrder right

    	  cout << node->bid.bidId << ": "
    	      		 << node->bid.title << " | "
    	  		     << node->bid.amount << " | "
    	  			 << node->bid.fund << endl;  //output bidID, title, amount, fund

      }
}

void BinarySearchTree::preOrder(Node* node) {
      // Pre order root
      if (node != nullptr) { //if node is not equal to null ptr

    	  cout << node->bid.bidId << ": "
    	      		 << node->bid.title << " | "
    	  		     << node->bid.amount << " | "
    	  			 << node->bid.fund << endl; //output bidID, title, amount, fund

    	  preOrder(node->left); //postOrder left
    	  preOrder(node->right);  //postOrder right

      }
}

/**
 * Remove a bid from the tree and rebalance using AVL rotations.
 *
 * @param node Current node in tree
 * @param bidId ID of the bid to remove
 * @return Root of the balanced subtree
 */
Node* BinarySearchTree::removeNode(Node* node, string bidId) {

    // Perform normal binary search tree deletion
    if (node == nullptr) {
        return node;
    }

    if (bidId.compare(node->bid.bidId) < 0) {
        node->left = removeNode(node->left, bidId);
    }
    else if (bidId.compare(node->bid.bidId) > 0) {
        node->right = removeNode(node->right, bidId);
    }
    else {
        // Node has no children
        if (node->left == nullptr && node->right == nullptr) {
            delete node;
            node = nullptr;
        }
        // Node has only a left child
        else if (node->left != nullptr && node->right == nullptr) {
            Node* temp = node;
            node = node->left;
            delete temp;
        }
        // Node has only a right child
        else if (node->right != nullptr && node->left == nullptr) {
            Node* temp = node;
            node = node->right;
            delete temp;
        }
        // Node has two children
        else {
            Node* temp = node->right;

            // Find the smallest node in the right subtree
            while (temp->left != nullptr) {
                temp = temp->left;
            }

            node->bid = temp->bid;
            node->right = removeNode(node->right, temp->bid.bidId);
        }
    }

    // If the tree became empty after deletion, return
    if (node == nullptr) {
        return node;
    }

    // Update the height of the current node
    node->height = 1 + max(getHeight(node->left), getHeight(node->right));

    // Calculate the balance factor
    int balance = getBalance(node);

    // Left-Left case
    if (balance > 1 && getBalance(node->left) >= 0) {
        return rotateRight(node);
    }

    // Left-Right case
    if (balance > 1 && getBalance(node->left) < 0) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    // Right-Right case
    if (balance < -1 && getBalance(node->right) <= 0) {
        return rotateLeft(node);
    }

    // Right-Left case
    if (balance < -1 && getBalance(node->right) > 0) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadBids(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            //cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

            // push this bid to the end
            bst->Insert(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98223";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales.csv";
        bidKey = "98223";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all bids
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            
            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            loadBids(csvPath, bst);

            cout << "AVL Tree Height: " << bst->GetTreeHeight() << endl;
            cout << "AVL Balance Status: "
                << (bst->IsBalanced() ? "Balanced" : "Not Balanced") << endl;

            //cout << bst->Size() << " bids read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            bst->InOrder();
            break;

        case 3:
            ticks = clock();

            bid = bst->Search(bidKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
            	cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 4:
            bst->Remove(bidKey);
            cout << "AVL Tree Height After Removal: "
                << bst->GetTreeHeight() << endl;

            cout << "AVL Balance Status After Removal: "
                << (bst->IsBalanced() ? "Balanced" : "Not Balanced") << endl;
            break;
        }
    }

    cout << "Good bye." << endl;

	return 0;
}
